
<html>
    <head>
        <title></title>
        <? include 'link.php'; ?> //links
         
    </head>
    <body>

    <div class="main-div">
        <h1>Payment of candidates</h1>
        <div class ="center-div">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>Address</th>
                            <th>Email</th>
                            <th>Pincode</th>
                            <th>Card type</th>
                            <th>Card Number</th>
                            <th>Expiration date</th>
                            <th>operation</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                      include 'connection.php';
                       $selectquery ="SELECT * FROM `payment of candidates`";
                        $query = mysqli_query($con,$selectquery);


                        while($res =mysqli_fetch_array($query)){
                    ?> 
                            <tr>
                            <td> <?php echo $res ['Name'] ;?> </td>
                            <td> <?php echo $res ['Gender'] ;?> "</br>"</td>
                            <td> <?php echo $res ['Address'] ;?> "</br>"</td>
                            <td> <?php echo $res ['Email'];?> "</br>"</td>
                            <td> <?php echo $res ['Pincode'];?>"</br>" </td>
                            <td> <?php echo $res ['Card type'];?>"</br>"</td>
                            <td> <?php echo $res ['Card number'];?> "</br>"</td>
                            <td> <?php echo $res ['Expiration date'];?> "</br>"</td>  
                            <td><i class="fa fa-edit" aria-hidden="true"></i></td>
                            <td><i class="fa fa-trash" aria-hidden="true"></i></td>
                            </tr>
                    <?php
                        }
                    ?>

                    
                    </tbody>  
                            
                    
                </table>
                
            </div>
        </div>
      </div>  
    </body>
</html>
