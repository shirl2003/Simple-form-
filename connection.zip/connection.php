<?php
$server ='localhost';
$username ="root";
$password ="";
$db='paymentform';


// Create connection
$conn =mysqli_connect($server, $username, $password,$db);

// Check connection
if ($conn) {
  ?>

  <script>
    alert('connection successfully');
  </script>
  <?php
}
else{
  ?>
  <script>
  alert('  No connection ');
  </script>

  <?php
}
?>