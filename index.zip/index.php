<html>
    <head>
        <title> Payment form </title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body >
        <div class="container">
            <form  method ="POST" > 
                
            
               <h1> Payment form</h1>
               <p>Required Fields are followed by *</p>
                <h2>contact information</h2>
               <p> Name:* <input type ="text" name="name" required></p>
                <fieldset>
                <legend>Gender*</legend>
               <p>
                 <input type="text" name ="gender" required> 
                </p>
                </fieldset>
                <p> Address: <textarea name="address" value ="address" cols="100" rows ="8" ></textarea></p>
                <p>Email:*<input type="email" name ="email" value="email" required></p>
                 <p>Pincode : *<input type="number" name="pincode" value="pincode" required></p>
                 <h2> Payment  Information </h2>
                 <p> card type:
                <select name="card type" id="card_type">
                <option value="">--select a card  type--</option>
                <option value ="visa">VISA</option>
                <option value ="Rupay">RUPAY</option>
                <option value ="Master card">MASTER CARD</option>
                </select>
                   </p>
                  <p>
                     * Card number : <input type ="number" name="card number" value="card number" required></p>
                 <p>
                   * Expiration Date :<input type ="date" name="exp_date"  value="exp_date" required>
                 </p>
                <p> * paynow :<input type ="submit" name="submit" value="pay now" required> </p>
            </form>
        </div>
    </body>

</html>

<?php
  include 'connection.php';

  if(isset($_POST['submit'])){
    $Name=$_POST['name'];
    $Gender=$_POST['gender'];
    $Address=$_POST['address'];
    $Email=$_POST['email'];
    $Pincode=$_POST['pincode'];
    $Cardtype=$_POST['cardtype'];
    $Cardnumber=$_POST['cardnumber'];
    $ExpirationDate=$_POST['expiration_date'];

    $insertquery="insert into payment of candidates(name, gender, address, email, pincode, cardtype, card Number, expiration date) VALUES ('$name','$gender','$address','$email','$pincode','$cardtype','$cardnumber','$expiration_date') ";
    $res=mysqli_query($conn,$insertquery);
    if ($res) {
      ?>
    
      <script type ="text/javascript">
        alert("Inserted  successfully");
        
          
      </script>
      <?php
    }
    else{
      ?>
        <script type="text/javascript">
          alert("No Inserted");
        </script>
        <?php
    }




  }

  /*"<?php echo htmlentities($_SERVER['PHP_SELF']);?>*/
  
  
?>

